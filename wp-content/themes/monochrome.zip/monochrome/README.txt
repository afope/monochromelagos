----------------------------------------------------------------------------
  Release notes for monochrome
----------------------------------------------------------------------------

  Version:3.0.4

  Live demo
  http://www.mono-lab.net/demo1/

  Plese send me your language file!
  mail@mono-lab.net



----------------------------------------------------------------------------
  Change log
----------------------------------------------------------------------------

  ver3.0.4 2010/06/06 Fixed page navigation.
  ver3.0.3 2010/06/01 Add new function.
  ver3.0   2010/04/16 Add new function.Fix style sheet and javascript error.
  ver2.6   2009/12/27 Add German language support. (Thank you Uli.)
  ver2.5   2009/12/20 Add Turkish language support. (Thank you Huseyin. http://gokekin.com)
  ver2.4   2009/12/07 Add Traditional Chinese language support. (Thank you Morgan.)
  ver2.3   2009/11/02 Add [EDIT] link in page-noside.php and page-noside-nocomment.php
  ver2.2   2009/09/21 Add Korean language support. (Thank you Jong-In. http://incommunity.codex.kr)
                      Add Spanish language support. (Thank you Ignacio. http://www.germanyague.com)
                      Add Dutch language support. (Thank you Niels. http://ritme.levendebrief.nl)
  ver2.1   2009/09/07 Add Catalan language support. (Thank you Marc. http://nuvolsgratis.cat/)
  ver2.0   2009/09/05 Add [ Exclude Pages and Categories form Header menu ] function.
                      Change format of copyright date (Thank you Jan. )
                      Fixed style.css ( hover color for even post )
                      Added Russian language support. (Thank you x-demon. http://x-demon.org/)
  ver1.7   2009/09/02 Added Brazilian portuguese language support. (Thank you Vinicius. http://vinicius.soylocoporti.org.br/)
                      Added Polish language support. (Thank you Karol.)
  ver1.6   2009/08/12 Added Chinese language support. (Thank you joojen. http://www.keege.com/)
  ver1.5   2009/08/02 Added Ukrainian language support. (Thank you Sasha.)
  ver1.4   2009/07/29 Fixed comment date.Plese replace "functions.php" and "comment.php" with new one. (Thank you chichi.)
  ver1.3   2009/07/26 Added French language support. (Thank you Reaves. http://www.catsjumping.com )
  ver1.2   2009/07/25 Added Danish language support. (Thank you Georg. http://wordpress.blogos.dk/ )
  ver1.1   2009/07/23 fixed page-nocomment.php,page-nocomment-noinfo.php,page-noside.php,page-noside-nocomment.php


----------------------------------------------------------------------------
  Lightbox problem
----------------------------------------------------------------------------

  This theme is using jQuery for javascript.
  So to work lightbox correctly plese try this WP-Slimbox plugin.
 
  WP-Slimbox2 (lightbox based on jQuery)
  http://wordpress.org/extend/plugins/wp-slimbox2/


----------------------------------------------------------------------------
   License
----------------------------------------------------------------------------

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

